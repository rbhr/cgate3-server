Serial Port Libraries

jspWin.dll              (Windows 32-bit) - already in root directory.
jspWin.dll.x64          (Windows 64-bit) - remove .x64 extension and copy to root directory.
libjspLux86.so          (Linux 32-bit) - already in root directory.
libjspLux86_64bit.so    (Linux 64-bit) - already in root directory.
libjspMacOSX.jnilib     (Mac OSX 32-bit) - already in root directory.
libjspMacOSX.jnilib.x64 (Mac OSX 64-bit) - remove .x64 extension and copy to root directory.