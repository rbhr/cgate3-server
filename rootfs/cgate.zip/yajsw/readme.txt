yajsw-stable-13.12

    * Update: commons configuration2 -> 2.10.1
    * Bug: posix: process restart rules.
    * Change: show warning if unsupported JSW property is used

Tested with JDK 22

Note: support the project by donating:

dogecoin: D84dTitLwAjvoTvZBi97mYdTKvtyJrc3xR
bitcoin:  bc1q5yghsmwj3k2ak7hpvrzd3gmpev5p089msqe4nr
polygon:  0xC46ffecEb6403452443AcC27E45335a589ca7eea

